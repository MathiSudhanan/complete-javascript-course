export const proxy = 'https://cors-anywhere.herokuapp.com/';
export const key = '462b1cc8d4f2730081462fbc65136320';
